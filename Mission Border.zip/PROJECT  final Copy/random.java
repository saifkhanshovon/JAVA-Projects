import java.util.Random;

public class random{
	
	public static int rndFun(){
		int[]a = new int[]{1020,1130,1240,1350,1460,1570,1680,1770,1880};
		 
		Random rnd = new Random();
		return (a[rnd.nextInt(a.length)]);
	}
	
}