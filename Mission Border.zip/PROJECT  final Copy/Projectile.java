// This program computes the trajectory of a projectile.

import java.util.*;
import java.util.ArrayList;

public class Projectile {
    // constant for Earth acceleration in meters/second^2
     static double ACCELERATION = -9.81;
	 
	public static ArrayList<Double> xList = new ArrayList<Double>();
	public static ArrayList<Double> yList = new ArrayList<Double>();

    public void projectileCordinate (double StrtX, double StrtY) {
		
        double velocity = 100;
	System.out.println(stage1.angle);
	
	double a=-1*stage1.angle;
	
	    System.out.println(a);
	
        double angle = Math.toRadians(a);
	

        int steps = 100;

        double xVelocity = velocity * Math.cos(angle);
        double yVelocity = velocity * Math.sin(angle);
        double totalTime = - 2.0 * yVelocity / ACCELERATION;
        double timeIncrement = totalTime / steps;
        double xIncrement = xVelocity * timeIncrement;

        double x = StrtX;
        double y = StrtY;
        double t = 0.0;

        for (int i = 1; i <= steps; i++) {
            t += timeIncrement;
            x += xIncrement;
			
			xList.add(round2(x));
            y = yVelocity * t + 0.5 * ACCELERATION * t * t;
			
			yList.add(round2(y));
            
        }
		
		
    }

    public static double round2(double n) {
        return (int) (n * 100.0 + 0.5) / 100.0;
    }
}
