import javafx.stage.Modality;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.geometry.*;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Paint;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;



public class Login {
    //static boolean answer;
	private TextField name;
	private TextField age;
	
	private  static String a;
	private  static String b;

	
	public String getName(){
		
		//System.out.println(a);
		return this.a;
		
	}
	
	
	public String getAge(){
		
		return this.b;
		
	}

    public void dispaly(){
        Stage loginWindow = new Stage();
        
        //Block Input From Other Window
        loginWindow.initModality(Modality.APPLICATION_MODAL);
        //loginWindow.setTitle(title);
       
			Button enterButton = new Button("ENTER");
			enterButton.setTextFill(Paint.valueOf("DARKRED"));
			enterButton.setFont(Font.font(null, FontWeight.BOLD, 26));
			
			name = new TextField();
			age = new TextField();
			
			VBox layout1= new VBox(10);
			layout1.getChildren().addAll(enterButton, name, age);
			layout1.setAlignment(Pos.CENTER);
			//layout1.setPadding(new Insets(10, 0, 0, 500));
        
        enterButton.setOnAction(e ->{
		a = name.getText();
		b = age.getText();
		loginWindow.close();
        });
        
        
        Scene scene = new Scene(layout1, 500, 500);
 
        scene.setFill(Paint.valueOf("DARKGREEN"));
        
        loginWindow.setScene(scene);
       loginWindow.showAndWait();

    }
}
