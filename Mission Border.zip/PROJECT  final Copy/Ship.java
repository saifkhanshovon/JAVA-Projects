import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.control.Button;
import java.util.*;
import javafx.geometry.*;
import javafx.application.Platform;
import javafx.scene.control.Label;


public class Ship implements Runnable {
	
	//ArrayList <Rectangle> tankList = new ArrayList <Rectangle> ();
	Group shipGroup = new Group();
	
	static int score = 0;
	Label scoreLabel = new Label("Score: " + String.valueOf(score));
	
	//ship object
	Rectangle ship1 = new Rectangle(2620,405,100,50);
	Rectangle ship2 = new Rectangle(2620,405,100,50);
	Rectangle ship3 = new Rectangle(2620,405,100,50);
	Rectangle ship4 = new Rectangle(2620,405,100,50);
	Rectangle ship5 = new Rectangle(2620,405,100,50);
	
	public void  insertInfo(){
		database db = new database();
		Login lg = new Login();
		//db.insert(lg.getName(),lg.getAge(),score);
		db.insert("a","b",0);
		}

	
	//return a group of ship objects
	public Group shipCollection(){
		Button beginBtn = new Button("BEGIN!!");
		beginBtn.setOnAction(e->{

		
		Thread t = new Thread(this);
		t.start();
	
	}
		
	);
	
	shipGroup.getChildren().addAll(beginBtn, ship1, ship2, ship3,ship4,ship5,scoreLabel);
	return shipGroup;
		
	}
	
	public void run() {
		
		Image shipImage = new Image("ship.png");
		//Image tankBlack = new Image("tankBlack.png");
		
		//setting X-axis of ship with random values
		ship1.setX(random.rndFun());
		ship2.setX(random.rndFun());
		ship3.setX(random.rndFun());
		ship4.setX(random.rndFun());
		ship5.setX(random.rndFun());
		
		
		//Fill Image for ships
		ship1.setFill(new ImagePattern(shipImage));
		ship2.setFill(new ImagePattern(shipImage));
		ship3.setFill(new ImagePattern(shipImage));
		ship4.setFill(new ImagePattern(shipImage));
		ship5.setFill(new ImagePattern(shipImage));
		
		
		
		
		
		
		//decreasing the position with time
		while(score!=200 && ship1.getX()!=100 && ship2.getX()!=100 && ship3.getX()!=100  && ship4.getX()!=100 && ship5.getX()!=100 ){
	
			double cx = ship1.getX();
			ship1.setX(cx-5);
			
			if(ship1.intersects(CannonBall.cBall.getBoundsInLocal())){
				System.out.println("touched1");
				ship1.setX(random.rndFun());
				CannonBall.cBall.setCenterX(2000);
				score+=10;
				Platform.runLater(() -> {
						scoreLabel.setText("Score: " + String.valueOf(score));
				});
			}
			
			double cx2 = ship2.getX();
			ship2.setX(cx2-5);
			
			if(ship2.intersects(CannonBall.cBall.getBoundsInLocal())){
				System.out.println("touched1");
				ship2.setX(random.rndFun());
				CannonBall.cBall.setCenterX(2000);
				score+=10;
				Platform.runLater(() -> {
						scoreLabel.setText("Score: " + String.valueOf(score));
				});
			}
		
			double cx3 = ship3.getX();
			ship3.setX(cx3-5);
			
			if(ship3.intersects(CannonBall.cBall.getBoundsInLocal())){
				System.out.println("touched1");
				ship3.setX(random.rndFun());
				CannonBall.cBall.setCenterX(2000);
				score+=10;
				Platform.runLater(() -> {
						scoreLabel.setText("Score: " + String.valueOf(score));
				});
			}
		
	
			double c4 = ship4.getX();
			ship4.setX(cx3-5);
			
			if(ship4.intersects(CannonBall.cBall.getBoundsInLocal())){
				System.out.println("touched1");
				ship4.setX(random.rndFun());
				CannonBall.cBall.setCenterX(2000);
				score+=10;
				Platform.runLater(() -> {
						scoreLabel.setText("Score: " + String.valueOf(score));
				});
			}
			
			double cx5 = ship5.getX();
			ship5.setX(cx3-5);
			
			if(ship5.intersects(CannonBall.cBall.getBoundsInLocal())){
				System.out.println("touched1");
				ship5.setX(random.rndFun());
				CannonBall.cBall.setCenterX(2000);
				score+=10;
				Platform.runLater(() -> {
						scoreLabel.setText("Score: " + String.valueOf(score));
				});
			}
			
	
			try{Thread.sleep(100);}
			catch(Exception ex){}
		}
		insertInfo();
	}
	
	
	
}