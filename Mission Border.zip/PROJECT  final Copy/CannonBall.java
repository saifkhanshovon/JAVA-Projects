import javafx.application.Application;
import javafx.scene.Scene;
import java.lang.Math.*;
import javafx.scene.Group;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

import java.util.*;

public class CannonBall extends Group implements Runnable{


	
	double centrX, centrY;
	
	
	public static Circle cBall;
	
	
	public CannonBall(double x,double y){
		
		cBall = new Circle(x,y,10);
		super.getChildren().add(cBall);
		centrX = x;
		centrY = y;
	}
	
	
	
	public void run(){
		
		Projectile p = new Projectile();
		p.projectileCordinate(centrX, centrY);
		ArrayList<Double> xNewList = p.xList;
		ArrayList<Double> yNewList = p.yList;
		
		Iterator<Double> j = xNewList.iterator();
		Iterator<Double> k = yNewList.iterator();
		
		while(j.hasNext()==true)
		{
			double cx = j.next();
			double cy = centrY - k.next();
			
			cBall.setCenterX(cx) ;
			cBall.setCenterY(cy) ;
			
			try{Thread.sleep(10);}
			catch(Exception ex){}
		}
		
		//stage1 s= new stage1();
		//s.shootBtn.setVisible(true);
		Projectile.xList.clear();
		Projectile.yList.clear();
		
	}
	
	
	
	
}